# Dif animation design

## Direction

Dif is an attentive companion, not an autonomous reviewer and not a progress meter. Preserve the soft purple-and-white panda from the supplied board, with a prop-free base body. Let the face and paws do the acting. Do not turn a code-review workspace into a stage: no bouncing through the diff, continuous waving, notification dances, glowing auras, or repetitive celebrations.

Produce a reusable visual vocabulary, but admit it in two steps. The foundation is a revised version of the three existing clip identities. The optional fidget and contextual cues are new design proposals, not additions already accepted by the current manifest, validator, or runtime RFC. The shared image-generation skill provides process and geometry checks; it does not grant product semantics or enlarge the runtime catalog.

## Proposed clips

| Clip | Tier | Frames | Frame time | Length | Playback | Intended gesture / use |
|---|---|---:|---:|---:|---|---|
| `calm_idle` | foundation | 12 | 250 ms | 3.0 s | loop | Quiet presence |
| `greet` | foundation | 8 | 125 ms | 1.0 s | one shot | Small hello |
| `rest` | foundation | 1 | 0 ms | Still | static | Awake still |
| `blink` | optional fidget | 6 | 100 ms | 0.6 s | one shot | Quiet blink |
| `compare_glance` | optional context | 8 | 150 ms | 1.2 s | one shot | Look between |
| `consider` | optional context | 8 | 150 ms | 1.2 s | one shot | Thoughtful pause |
| `comment_ready` | optional context | 8 | 125 ms | 1.0 s | one shot | Here is the draft |
| `attention` | optional context | 6 | 150 ms | 0.9 s | one shot | Worth a look |
| `acknowledge` | optional context | 8 | 125 ms | 1.0 s | one shot | A small nod |
| `blocked` | optional context | 6 | 150 ms | 0.9 s | one shot | Patient help needed |


All durations are proposed art-direction targets, not measured results. All animated clips except `calm_idle` are finite one-shots. There is deliberately no separate endless loading/typing/thinking loop: real status text continues independently of the short character gesture. The one-shot returns to the neutral calm pose when it ends; a task need not have completed when the gesture finishes.

## Foundation first

`calm_idle` uses 12 frames at 250 ms (3 seconds), rather than the source snapshot's three-frame 750 ms loop. It is a local breathing deformation, not a uniform whole-image pulse. `greet` uses eight frames at 125 ms (1 second), rather than five frames of squash. `rest` is the exact awake neutral representative. These are proposed revisions; do not describe their changed art or timing as existing approved content.

Keep the original three IDs and source/generated directory conventions. In this candidate, `calm_idle` representative frame is 0, `greet` representative frame is 3, and `rest` representative is 0. The final greeting frame, idle frame 0, and static rest reuse the same approved registered neutral pixels. Idle's last frame must be a nearby, visibly distinct breathing phase, not a duplicate of frame 0. Inspect the seam after the actual 256-pixel shipping reduction.

The foundation has 21 content cells, or 5.25 MiB of RGBA8 pixels. Six blank end cells raise its three decoded strips to 27 cells / 6.75 MiB, before container/Qt overhead. Proposed strip sizes are 3584 x 256 (`calm_idle`), 2560 x 256 (`greet`), and 768 x 256 (`rest`). This fits the existing size/frame/rate ceilings, but does not by itself approve the new bytes, timings, or prop-free identity revision.

## Optional repertoire

### blink

**When:** Only after a future fidget policy is approved: at a calm-loop boundary on the exposed landing, for example after four completed three-second loops.

**Meaning:** A natural blink, not an acknowledgement or a change in application state.

**Motion:** Change only the eyelids. Retain the neutral body, ears, eye-patch shapes, nose, mouth, paws, feet, camera, and light. The whole image must not be squashed to make the eyes close.

### compare_glance

**When:** One deliberate comparison-selection gesture in a future explicitly admitted illustration surface; not every scroll tick or source-line selection.

**Meaning:** Looking between two sides. Not proof that any code has been inspected by an agent or that all differences are understood.

**Motion:** A restrained left-to-right glance. Eyes carry most of the action; head yaw is at most about two degrees. No magnifying glass, cards, arrows, or generated code.

### consider

**When:** Once when an explicitly launched assistant task enters its accepted working state, only in a future permitted task illustration slot.

**Meaning:** A brief thoughtful gesture accompanying separately rendered working status. Not a model identity, hidden reasoning display, or progress estimate.

**Motion:** Bring the viewer-left paw lightly near the chin, tilt the head a little, then return. This is a one-shot, not a pantomime that repeats for the entire task. No thought bubbles or floating dots.

### comment_ready

**When:** A local draft or response has actually been accepted into the visible result model; not merely a submitted generation request.

**Meaning:** Invites the user to read a real draft. Does not say that the draft is correct, approved, or published.

**Motion:** Dif makes a small two-paw presentation gesture toward the real UI beside or below the illustration. The sprite itself contains no note, speech bubble, code, text, pen, or author badge.

### attention

**When:** A relevant new finding or actionable condition is accepted for the current context; coalesce a batch into at most one cue.

**Meaning:** Something merits the user's attention. A candidate finding is not a confirmed defect.

**Motion:** A small, polite raised-paw gesture and slightly more attentive eyes, followed by a return to neutral. No alarm, bouncing, red flash, exclamation symbol, bug, or accusing finger.

### acknowledge

**When:** A user-initiated operation has a matching accepted success terminal. Publication requires an actual confirmed publication receipt; local save requires durable success.

**Meaning:** That requested action completed. It does not mean the code is good, safe, reviewed, or approved.

**Motion:** One small affirmative nod with a warm, closed smile. Rotate the head a little; do not compress the entire body. No green check, thumbs-up, medal, confetti, or party pose.

### blocked

**When:** An accepted state genuinely needs user action, such as reauthentication or an unavailable required capability. Never a normal cancellation.

**Meaning:** A calm invitation to read the real explanation and recovery controls; not shame, blame, or data loss.

**Motion:** A slight inquisitive head tilt and a small open-paw gesture. Keep the emotional tone patient and capable. No crying, sweat drop, anger, broken-object prop, shrugging despair, or question mark.

## Where and when Dif appears

The current RFC-BPR-0020 contract is landing-only: Dif disappears when an active PR occupies the review surface. Preserve that for the foundation. The contextual repertoire would require a later explicit placement/semantic change: a reserved illustration slot in an explicitly opened assistant/task surface, never over source text, the diff-link map, conversation text, controls, or the selected-line detail. Do not quietly introduce a persistent toolbar mascot or replace human/model author avatars with Dif.

A future cue selector must consume already-accepted UI-facing facts with the correct current request/context identity. It must not launch work, inspect source to invent findings, infer completion from time, or mutate review state. A model-produced draft keeps its actual provider/model/effort provenance beside the text. Dif is not the speaker or author.

Keep ordinary work quiet. No gesture per token, keystroke, wheel tick, file row, or streamed finding. Coalesce a newly accepted batch to one relevant cue, and keep at most one pending contextual cue instead of a backlog. Re-check relevance before playback and drop a cue if its request/review is no longer current. An actual error/action-needed state outranks a generic success or decorative fidget. Cancellation returns calmly; it is not a failure.

For the optional blink, a simple proposed policy is one blink after four full calm cycles (about 12 seconds), at a loop boundary, only while exposed and active. Do not introduce a second random timer. This policy is outside the current no-fidget foundation and must be reviewed before activation. Greeting remains once per new landing generation, not once per activation.

## Motion and transitions

Use one stable neutral pose as the common handoff. Prop-free artwork avoids a card appearing/disappearing whenever a short gesture begins. Idle is the only always-repeating animation. Do not loop one-shots to stand in for a long task. When an important state change, navigation, deactivation, or motion-preference change makes a clip irrelevant, stop it without delaying the application to finish the pose. The actual state text and controls update immediately.

Reduced motion displays static neutral/rest with no fades, pulses, bobs, or one-shots. There are no timed frame changes while hidden or inactive. Later contextual cues must still be fully communicated by real text and controls when all mascot motion is absent. Do not animate a chat log full of Dif instances or make one mascot per result.

## Props and symbols

The base master and all ten proposed clips are prop-free. A future diff-card branding variant is optional, separately source-owned, and separately reviewed; it does not justify an inseparable base card. Retain independent character source and prop/occlusion layers if such a variant is authored, then compose the approved final variant offline. Do not add a skeletal rig or runtime layer system just to ship the foundation.

Plus/minus marks are abstract review decoration only. Check marks, issue severity, locks, provider identity, publication receipts, progress indicators, and actual wording should be rendered by the application using its real state and accessible UI, not baked into the sprite. Do not import Nib's magnifying glass or Mel's petals/glow to make a pose more recognizable.

## What not to produce

No sleeping fallback (reduced motion is not sleep/offline). No "Dif approved your PR" animation. No triumphant defect-found reaction. No request-changes scowl, guilt, tears, confetti, spinning loader eyes, talking mouth, or fake typing. No render of all expressions in one production atlas. No background plate required to make Dif readable on dark or light surfaces.

## Full-set resource consequence

All ten clips total 71 content frames. At 256 x 256 RGBA8 this is 17.75 MiB; 20 blank end cells make 91 cells / 22.75 MiB before overhead. It exceeds the current 48-content-frame and three-clip contract and the 13.5 MiB complete-strip cap. The current code also hard-codes the allowed IDs. Therefore the optional repertoire remains outside the live asset root. A later bounded subset or an explicitly revised residency/catalog contract must be agreed before shipping more clips; do not merely raise constants until a validator passes.
