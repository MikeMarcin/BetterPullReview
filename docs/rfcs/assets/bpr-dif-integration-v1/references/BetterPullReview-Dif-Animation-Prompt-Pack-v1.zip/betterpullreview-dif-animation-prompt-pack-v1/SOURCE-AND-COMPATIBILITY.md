# Source baseline and integration constraints

## Materials inspected

The attached `better_pull_review_project_source.md` is the source snapshot, generated 2026-09-12T19:50:30-07:00. Relevant repository files were read directly, including RFC-BPR-0019, RFC-BPR-0020, the Dif asset README and runtime manifest, and `scripts/dif_assets.py`. The attached `sprite-sheet-animation-updater.zip` was unpacked and its SKILL.md, validator, and test were read. The two supplied PNGs were inspected as visual reference, not sliced into new production frames.

The image bytes match the historical reference hashes recorded in BPR's existing provenance: brand board `cf35d96198e20575069b3dd43edd352a04393e457970219738a9e888458729c0`, and group image `5859655aa4c39e50a7e3c522e48f8b34c48bd5749553089be95860e7f2d0f39e`. This identity match does not make newly generated production frames approved.

## Observed contract versus this proposal

| Item | Source snapshot | Proposed work here |
|---|---|---|
| Catalog | Exactly `calm_idle`, `greet`, `rest`, in that order | Keep these three for foundation; seven optional clips stay staged outside it |
| Idle | 3 frames, 250 ms, representative 1 | 12 frames, 250 ms, representative 0 |
| Greeting | 5 frames, 125 ms, representative 2 | 8 frames, 125 ms, representative 3 |
| Rest | 1 frame, 0 ms, awake | Same identity/behavior; new prop-free pixels |
| Master | Transparent source at least 512 square; actual existing master documented as 1024 square | New 1024-square prop-free revision; frozen 512-square working neutral |
| Source images | Square multiples of 256, max 2048 per dimension | 512-square frames; row jobs are intermediates, not source-tree members |
| Runtime | 256-square RGBA8 sRGB, straight alpha | Preserved |
| End gutters | One entire blank cell at each strip end | Added by BPR compiler, never requested as generated content frames |
| Alpha clearance | 16 runtime pixels, all nonzero alpha counted | Preserve; 32 pixels in each 512-source cell |
| Geometry | Center 128; baseline 223; envelope [56,22,200,224]; foot tolerance 1 | Preserve as registration target; measure actual new reference rather than changing proportions |
| Core prop | Existing reviewed rasters still contain card; later owner note requires separability | All new base clips contain no card or other prop |
| Placement | Landing only, not active review or comment avatars | Preserve foundation; optional context placement needs an explicit later change |
| Status | Asset/program RFCs are Deferred; existing asset subject verdicts do not equal runtime composition | This package is design/prompt material only, no status or acceptance changes |

The code's `_alpha_bounds()` uses exclusive right/bottom coordinates. `_validate_runtime_geometry()` compares that bottom with `baseline_y`. Thus target bottom 223 means the last occupied pixel row is nominally 222, with the existing one-pixel tolerance. At 512 source resolution the analogous boundary is 446. Treat the coordinate convention explicitly when registering source art; do not add a one-pixel hop through inclusive/exclusive confusion.

## Three incompatible notions of a sheet

1. **Generation row:** at most four active 512-square cells, no blank end cells. Four cells produce 2048 x 512. Longer animations use several ordered row jobs.
2. **Registered source frames:** one square image for each numbered frame. BPR's source reader does not accept a long source row as a substitute for the declared separate PNGs.
3. **BPR generated runtime strip:** `(content_count + 2) x 256` wide and 256 high, with a fully blank cell at both ends. The catalog's first content rectangle starts at x=256.

The shared validator begins reading active frames at column zero and exposes no leading-offset argument. Passing a BPR runtime strip as `--animations greet:8` makes it test the intentionally blank first cell as content. Validate the content-only authoring rows with the shared tool, and validate padded runtime strips with BPR's own tool. A temporary content-only crop of a generated strip is also possible for inspection, but must not replace or edit the shipping strip.

## Shared-validator limits

The bundled color detector recognizes a specific blue mascot. Its only `--body-color` choice is `mascot-blue`; adjusting width/height ranges does not make it detect purple and white Dif. Use `--no-body-check` for the structural pass, with an independent consumer/visual registration check. This flag disables the body check; it does not certify it.

The actual implementation checks dimensions, active-frame alpha/gutters, and (when enabled) blue-body width/height/center drift. It does not implement baseline, loop-seam, source identity, props-versus-body segmentation, or blank unused-cell checks. The skill workflow asks for those checks, but the script alone does not provide them. BPR's geometry and loop/handoff validation plus real-speed visual review remain necessary.

BPR's current geometry validator also measures the whole visible alpha envelope, not a semantic torso mask. A card, bubble, or raised hand can change that envelope without moving the actual pelvis. Do not auto-recenter artwork around that envelope. The prop-free foundation keeps the paw wave within the existing silhouette width; later wider gestures/props need deliberate geometry validation, not secretly relaxed tolerances.

## Current source/tool locations

- `docs/rfcs/RFC-BPR-0019-dif-visual-identity-sprite-assets.md`: identity, first three clips, art/source/runtime separation, limits, and review requirements. Snapshot lines 161540–161919.
- `docs/rfcs/RFC-BPR-0020-animated-dif-mascot-qt-composition.md`: landing placement, motion preference/lifecycle, prop-separation note, no semantic mascot conclusions. Snapshot lines 161920–162435.
- `src/adapters/qt/assets/dif/README.md`: current production history, timings, geometry, commands, and downstream restriction. Snapshot lines 374264–374415.
- `src/adapters/qt/assets/dif/dif-sprite-manifest.json`: exact current three-clip schema. Snapshot lines 374416–374540.
- `scripts/dif_assets.py`: exact clip admission, alpha bounds, canonical codec, deterministic fixed-box resize, source inventory, loop/handoff and generated-product checks. Snapshot heading starts at 305061.
- Shared skill: `sprite-sheet-animation-updater/SKILL.md` and `scripts/validate_sprite_sheet.py` in the supplied ZIP.

An older README/RFC promises byte-identical regenerated PNGs. The inspected current script deliberately compares canonical decoded PNG content rather than pinning the compressed DEFLATE byte stream across zlib implementations; its digest inventory still binds the committed output bytes. Follow the live tool, do not replace that portability behavior with a new compressor pin.

## Production boundary

Do not use this design plan JSON as `dif-sprite-manifest.json`. It intentionally describes work not admitted by schema v1. Do not copy all prompt files, original brand boards, source rows, optional clips, or candidate masks into the live Dif root: its inventory is exact. Keep authoring material in a separate staging directory such as `artifacts/dif-animation-candidates/` until a scoped asset change is accepted.

New source bytes, altered timing, neutral poses, generator behavior, or manifests need updated provenance/digests and the affected visual review. Existing approvals cannot be carried forward by filename. The current plus/minus card is not removed at runtime by masking/inpainting. A new prop-free source revision solves that correctly before runtime selection.
