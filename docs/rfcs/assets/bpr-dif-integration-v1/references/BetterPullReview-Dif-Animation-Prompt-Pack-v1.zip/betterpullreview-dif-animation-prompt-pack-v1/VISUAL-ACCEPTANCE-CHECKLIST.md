# Dif candidate review

Review the actual assets, not only this plan. A prompt establishes intent, not compliance.

## Identity and shape

Confirm the same eyes, catchlights, eye-patch geometry, nose, head/body ratio, material, and purples across every frame. Confirm that the prop-free character has natural paws and a complete belly. Reject a melted hand, extra digit/limb, asymmetric unexpected foot, different panda face, changing light, or noisy fur pattern. Measure the torso/root separately from moving hands or optional props; the full alpha envelope alone does not establish root stability.

## Fixed cells and alpha

Check the actual PNG dimensions, straight alpha, all nonzero-alpha extents, empty inter-cell margins, and all six foundation runtime end-gutter cells. Reject baked checkerboards, opaque backgrounds, stray alpha pixels, clipped tips, gray/green fringes, and hidden RGB under alpha zero. Do not remove a pale facial highlight as if it were background. Confirm zero RGB under fully transparent source pixels before source admission.

## Motion

Play at declared speed at 64, 72, and 96 logical pixels, not only zoomed at 512. Inspect several idle loops: no foot lift, breathing hitch, terminal dwell, whole-body zoom, or texture boiling. Inspect greet-to-idle and static-rest handoffs. A one-shot may intentionally begin/end neutral; never run a loop-seam test on it as if it were a repeating clip. Verify neutral anchors are pixel-equal after the actual runtime reduction; verify idle's distinct terminal phase remains nonidentical and inside the existing seam threshold.

## Theme and size

Composite over the actual BPR light/dark and both high-contrast backgrounds. Keep context plates outside runtime assets. Confirm facial features and paws read at shipping scale without glow or a background plate. Match the application's scale factors in the attended preview; enlarging an image in a browser is not target-native DPR evidence.

## Meaning and interruption

The core greeting is not success, a nod is not approval, an attention gesture is not a confirmed defect, and still rest is not offline or asleep. A canceled/stale request must not produce a later success reaction. All status survives with Dif hidden or motion reduced. Pausing or navigating must not wait for animation completion. Optional cue behavior needs its own later product evidence and is not tested by the foundation asset preview.

## Honest deliverable record

Record source and output hashes, inspected live metadata, all actual commands/results, remaining visual defects, and which reviews have not occurred. Do not claim runtime integration or target-platform animation testing from an offline image pack. Do not transfer an old digest-bound production verdict to newly generated pixels.
