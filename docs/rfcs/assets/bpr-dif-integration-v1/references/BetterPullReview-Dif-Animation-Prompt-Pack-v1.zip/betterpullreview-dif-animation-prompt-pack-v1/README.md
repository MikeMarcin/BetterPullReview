# BetterPullReview — Dif animation prompt pack v1

A proposed animation repertoire and image-generation/import brief based on the two supplied Dif references, the supplied sprite-sheet-animation-updater skill, and the 2026-09-12 BetterPullReview source snapshot.

**Start with the prop-free neutral master, then the three foundation clips.** The other seven clips are deliberately staged proposals. This package contains no newly generated animation artwork, accepted new source frames, runtime implementation, or production approval.

## Contents

- `ANIMATION-DESIGN.md`: ten-clip design, intended triggers, motion/placement rules, and resource consequences.
- `GENERATION-PROMPTS.md`: all complete copy/paste image prompts, grouped into small single-row jobs.
- `prompts/`: the same prompts as separate plain-text files, plus alpha and single-frame fallback instructions.
- `animation-design-plan.json`: structured authoring plan, exact frame descriptions, row order, timings, and neutral anchors. **Not the runtime manifest.**
- `UPDATER-HANDOFF.md`: task prompt and actual inspected validation commands for the skill.
- `SOURCE-AND-COMPATIBILITY.md`: source audit, current-versus-proposed behavior, and important validator/layout mismatches.
- `consumer-config/project.md`: optional draft consumer-owned skill guidance; not installed or applied.
- `VISUAL-ACCEPTANCE-CHECKLIST.md`: identity, geometry, alpha, real-speed/theme/size and meaning checks.
- `reference-inputs/`: byte-identical copies of the two supplied images, for reference only; never copy the boards into runtime assets.
- `INPUT-HASHES.json`: exact input and inspected-skill hashes.

## Generation order

Approve `prompts/00-prop-free-neutral-master.txt` first. Prepare one registered neutral source and reuse it for static rest and designated handoff frames. Produce the three calm-idle row jobs, then the two greeting row jobs. Review that foundation at shipping speed and size before spending effort on the optional repertoire.

Every image-generation job uses the same approved master as reference. A four-frame row requests 2048 x 512 pixels; a two-frame tail requests 1024 x 512. These are authoring jobs, not a new runtime sheet layout. If the image tool cannot provide those dimensions with useful per-cell resolution, use the supplied single-frame fallback and assemble offline. Do not trust requested dimensions, transparency, or identical character wording without checking actual outputs.

Use `UPDATER-HANDOFF.md` inside the real checkout for authoring/integration. Current BPR only admits the three foundation IDs and fully blank leading/trailing runtime cells. The shared skill's structural validator expects content starting in the first cell and has a blue-mascot default detector. Both differences are handled explicitly in the handoff; a generic validator pass is not a complete Dif motion/identity check.
