# Handoff to sprite-sheet-animation-updater

Use this as the task prompt for the agent running inside the actual BetterPullReview checkout. This pack is not an implementation RFC and not permission to compose previously deferred semantic cues into the product.

```text
Use $sprite-sheet-animation-updater to author the FOUNDATION candidate described in this Dif animation prompt pack: a new prop-free neutral master, calm_idle (12 x 250 ms), greet (8 x 125 ms), and rest (1 static). Read ANIMATION-DESIGN.md, SOURCE-AND-COMPATIBILITY.md, and animation-design-plan.json. Keep all optional clips staged and unbound. Do not run an all-repertoire runtime import.

First resolve the skill's installed SKILL.md and bundled script paths to absolute paths, including MASK symlinks. Read the consumer's existing .mask/skill-config/sprite-sheet-animation-updater/project.md if it exists. The enclosed consumer-config/project.md is proposed guidance only: merge it deliberately, not as a blind overwrite. Inspect the live asset manifest, source master, dif_assets.py, relevant tests, and RFC-0019/0020 before applying any file changes; the attached snapshot is a baseline, not proof that the checkout is unchanged.

Use the supplied PNGs only as reference. They are opaque concept compositions, not production frames. View the current accepted master when present. Generate and approve the new prop-free master first, preserving the established character. Freeze one registered 512-square working neutral derived from the 1024-square source master with an inspected deterministic preparation method. Record tool and input/output hashes. Do not invent or reuse a prior production verdict for the changed art.

Generate one row job at a time from prompts/, always attaching the same frozen neutral/model reference. Each job has four cells, or two for the short tail, at 512 square per cell; do not make a multirow all-emotions sheet. If the generator cannot deliver useful per-cell resolution, generate the named frames individually and assemble offline. Validate actual dimensions and transparency rather than trusting the prompt. Keep generation/tool/provider limitations explicit.

Register the neutral once. Split accepted rows on the exact fixed grid with no per-frame auto-trimming, scale fitting, body recentering, or background plate. Keep both feet at the declared source baseline. Use source-level localized corrections only where necessary; reject character drift rather than deforming a different panda into the target box. Neutral anchors designated in the plan are copied from the frozen neutral pixels, not regenerated. The final calm-idle frame must remain different from its first frame after the actual runtime resize, with a smooth seam. Greet's last frame, calm's representative, and rest must use the same neutral.

Run the bundled validator on CONTENT-ONLY rows with explicit dimensions/counts, --alpha-threshold 0, --min-gutter 32, and --no-body-check. The default blue-body detector is wrong for Dif, and passing the structural check is not body/identity approval. Do not point it directly at BPR strips with blank leading cells. Verify body/foot registration, face/material stability, hidden RGB cleanup, seams, handoffs, and actual UI light/dark/high-contrast composites separately. Review at 64, 72, and 96 logical pixels, at declared speed, including several loop cycles and interruption/static cases.

Stage only the three foundation clips in a separate candidate asset tree using the live schema and canonical source filenames. Update that candidate's approved-source inventory/provenance, timing, representative-frame metadata, and hashes as required, without claiming they are already approved. Keep original references, prompts, row intermediates, optional clips and review plates outside that exact inventory. Use the live BPR PNG codec/canonicalization requirements and offline compiler for shipping reduction; do not substitute a new runtime resizer or edit generated strips by hand.

Use scripts/dif_assets.py generate into a NEW empty output directory. Install those generated products into the isolated candidate only, then run validate, verify, preview, and relevant existing asset tests. Keep runtime resource binding/composition separate under the established RFC-0020 boundary. Do not change settled RFC status or activate AI/approval/error mascot semantics merely because this prompt pack contains proposals.

Deliver the candidate source frames and generated strips with manifest/provenance, direct check results, measured geometry/resource counts, theme/scale plates, real-speed previews, and the precise unresolved visual decisions. State explicitly which source frames are accepted, which were rejected, and what has not run. Do not call candidate artwork production-ready or Auto-Verified based only on static contact sheets or a generic validation pass.
```

## Structural command example

Resolve `SKILL_DIR` from the actual installed skill link. Here `ROW` names one accepted content-only row, not a padded runtime strip. Run from the BetterPullReview checkout. Omit `--json` for a normal human-readable result; add it only for a machine consumer.

```sh
python3 "$SKILL_DIR/scripts/validate_sprite_sheet.py" \
  --sheet "$ROW" \
  --cell-width 512 --cell-height 512 \
  --columns 4 --rows 1 \
  --animations greet_part_1:4 \
  --alpha-threshold 0 --min-gutter 32 \
  --no-body-check
```

For a two-frame tail, use `--columns 2 --animations attention_part_2:2`.

## Existing BPR command sequence

Set `CANDIDATE`, `NEW_OUTPUT`, and `NEW_PREVIEW` to absolute staging paths. Output directories must be new/empty. Run from the checkout after the candidate's complete source inventory and metadata have been prepared. These commands are real inspected interfaces, not commands executed by this prompt pack.

```sh
python3 scripts/dif_assets.py generate --assets "$CANDIDATE" --out "$NEW_OUTPUT"
# Copy only the generated products into CANDIDATE/generated; preserve source ownership.
python3 scripts/dif_assets.py validate --assets "$CANDIDATE"
python3 scripts/dif_assets.py verify --assets "$CANDIDATE"
python3 scripts/dif_assets.py preview --assets "$CANDIDATE" --out "$NEW_PREVIEW"
ctest --preset dev -R '^dif_assets_contract$' --output-on-failure
```

The existing CTest selector checks the checkout/test contract, not an arbitrary staging directory by magic. Record separately which candidate checks passed and which checkout tests were exercised. Update affected count/representative/identity tests only in the scoped asset integration change. Do not mark the optional ten-clip repertoire admitted by running the three-clip test.
