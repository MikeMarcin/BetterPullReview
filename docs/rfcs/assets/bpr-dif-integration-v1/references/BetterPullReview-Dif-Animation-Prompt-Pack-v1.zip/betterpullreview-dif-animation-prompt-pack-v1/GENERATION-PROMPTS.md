# Dif image-generation prompts

These are proposed generation jobs, not already-generated or approved artwork. Start with the neutral master. Attach the approved prop-free master to every later job. Use the four-cell batches below rather than asking a generator for a huge all-animation atlas. Frames are numbered from zero in the instructions, but numbers must never appear in the artwork.

## 00. New prop-free neutral master

```text
Create one new production master of Dif, the panda mascot for BetterPullReview, using the supplied Dif Panda Code Review Brand Board as identity reference. Use the large purple-and-white panda in the board's main concept panel, not the alternate color explorations. The BetterPullReview Mascot Lineup is secondary lighting/material reference for Dif only; do not introduce Nib, Mel, or their features. If the current accepted Dif neutral master is also attached, preserve its established facial features and proportions while making this explicitly requested prop-free revision.

Dif is a compact, softly dimensional plush-like panda with rounded purple ears, purple eye patches, short purple arms and feet, a pale warm lavender-white face and belly, large glossy dark eyes with consistent small catchlights, a small purple nose, and a gentle closed smile. Retain the reference's friendly silhouette and polished soft 3D illustration style. Fine soft surface texture is welcome; loose furry strands, glitter, painterly edges, plastic gloss, and changing fur noise are not.

Front-facing full body, camera at face height, near-orthographic presentation, fixed soft frontal studio lighting. Both eyes open, both feet planted, shoulders level, hips centered, paws relaxed beside the lower belly. Show complete anatomically plausible paws and torso: do not merely erase a card and leave gripping hands or a blank card-shaped hole. Do not redesign the character.

No props at all: no diff card, plus/minus symbols, magnifying glass, pen, tablet, speech bubble, thought dots, badges, clothes, logos, letters, numbers, UI, or other characters. No floor, cast shadow, contact shadow, halo, ground glow, bloom, vignette, scene, or border.

Output one isolated character on a genuinely transparent alpha background, not a painted checkerboard or white plate. Target a 1024 x 1024 RGBA PNG. Keep the body's reference center at x=512, with the planted-foot line near y=892. Contain all visible pixels comfortably within x=224..799 and y=88..895. These numbers describe a containment envelope, not a rectangle to fill: preserve natural aspect and proportions instead of stretching Dif. Keep enough room inside the same envelope for a later small raised-paw wave.

This is a single neutral master, not an expression sheet, character lineup, labeled model sheet, or animation. Output only the artwork.
```

## Shared production rule

Source row jobs request at most four square 512-pixel cells: four frames = 2048 x 512, two frames = 1024 x 512. They are ordered pieces of one clip, not separate runtime clips. If the generator cannot deliver that layout with at least 512 effective pixels per cell, generate the specified poses individually as 512 x 512 images against the same master and assemble the row offline. Do not stretch a 1536-pixel-wide four-frame image into a purported high-resolution source. A newly approved 1024-pixel master remains the high-resolution identity source. Do not regenerate still and neutral handoff frames: copy them from the frozen source after registration.

## 01. calm_idle — Quiet presence

12 frames; 250 ms/frame; loop; total 3 seconds. Decorative presence, not loading, analysis, progress, or review approval.

One soft, three-second breathing cycle. Keep the face, pelvis, and feet registered. Animate a small local chest/shoulder deformation, not a scale transform of the entire panda. No blink in this loop.

### Frames 00–03

Save the accepted raw row as `calm_idle-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Quiet presence' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 12-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
One soft, three-second breathing cycle. Keep the face, pelvis, and feet registered. Animate a small local chest/shoulder deformation, not a scale transform of the entire panda. No blink in this loop.

Cell 1 (clip frame 00): Exact neutral reference pose: awake, paws relaxed beside the belly, both feet planted.
Cell 2 (clip frame 01): Begin the inhale: chest rises approximately 0.5 runtime pixel; head, hips, and feet stay fixed.
Cell 3 (clip frame 02): Inhale continues: chest rises approximately 1 runtime pixel; expression unchanged.
Cell 4 (clip frame 03): Chest rises approximately 1.5 runtime pixels; only a slight local shoulder response.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–07

Save the accepted raw row as `calm_idle-04-07.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Quiet presence' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 07 of a 12-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
One soft, three-second breathing cycle. Keep the face, pelvis, and feet registered. Animate a small local chest/shoulder deformation, not a scale transform of the entire panda. No blink in this loop.

Cell 1 (clip frame 04): Soft inhale peak: chest rises approximately 2 runtime pixels; no inflated balloon belly or head enlargement.
Cell 2 (clip frame 05): Ease off the inhale peak: chest rise approximately 1.5 runtime pixels.
Cell 3 (clip frame 06): Exhale: chest rise approximately 1 runtime pixel.
Cell 4 (clip frame 07): Exhale continues: chest rise approximately 0.5 runtime pixel.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 08–11

Save the accepted raw row as `calm_idle-08-11.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Quiet presence' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 08 through 11 of a 12-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
One soft, three-second breathing cycle. Keep the face, pelvis, and feet registered. Animate a small local chest/shoulder deformation, not a scale transform of the entire panda. No blink in this loop.

Cell 1 (clip frame 08): Pass smoothly through neutral breathing volume; do not pause or restart the action.
Cell 2 (clip frame 09): Small relaxed exhale: chest falls approximately 0.5 runtime pixel below neutral.
Cell 3 (clip frame 10): Soft exhale trough: chest falls approximately 1 runtime pixel; feet and head remain fixed.
Cell 4 (clip frame 11): Recover toward neutral: chest is approximately 0.5 runtime pixel below neutral. This is a genuinely different pose from frame 00, close enough to continue smoothly into it. Do not duplicate frame 00.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

## 02. greet — Small hello

8 frames; 125 ms/frame; one_shot; total 1 seconds. A greeting only. Never a signal that sign-in, loading, a review, or a publication succeeded.

One small, relaxed wave with the paw on the viewer's right. Keep the paw inside the existing head-width envelope; keep the opposite paw and both feet fixed. No whole-body squash, jumping, bowing, hearts, or sparkles.

### Frames 00–03

Save the accepted raw row as `greet-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Small hello' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
One small, relaxed wave with the paw on the viewer's right. Keep the paw inside the existing head-width envelope; keep the opposite paw and both feet fixed. No whole-body squash, jumping, bowing, hearts, or sparkles.

Cell 1 (clip frame 00): Exact neutral reference pose; both paws down, eyes open.
Cell 2 (clip frame 01): Viewer-right paw lifts a little toward the upper belly; elbow stays close to the body.
Cell 3 (clip frame 02): Paw rises beside the lower cheek, below the ear, with rounded paw pads gently facing the viewer.
Cell 4 (clip frame 03): Small outward wrist turn; welcoming expression but no larger head or exaggerated mouth.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–07

Save the accepted raw row as `greet-04-07.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Small hello' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 07 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
One small, relaxed wave with the paw on the viewer's right. Keep the paw inside the existing head-width envelope; keep the opposite paw and both feet fixed. No whole-body squash, jumping, bowing, hearts, or sparkles.

Cell 1 (clip frame 04): Small inward wrist turn: complete the single restrained wave without changing the body position.
Cell 2 (clip frame 05): Paw begins lowering from the cheek toward the chest.
Cell 3 (clip frame 06): Paw nearly returned to the relaxed neutral position; eyes and smile return exactly to neutral.
Cell 4 (clip frame 07): Exact neutral reference pose, matching calm_idle frame 00 and rest. This frame will be copied from the locked neutral source during assembly.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

## 03. rest — Awake still

REST ASSET — REUSE INSTRUCTION, NOT A NEW GENERATION REQUEST

Use the approved prop-free neutral master to produce the frozen, registered 512 x 512 neutral source with the agreed deterministic preparation step. Copy that same image to source/rest/frame-000.png in the staged candidate and to every designated neutral anchor. The 1024 x 1024 approved master remains source/dif-neutral-master.png.

Dif is awake, paws relaxed, eyes open. No sleep pose, blink, fade, procedural breathing, background, or status meaning. Do not send this asset to an image generator: independently regenerating rest would weaken exact rest/idle/greeting continuity.

## 04. blink — Quiet blink

6 frames; 100 ms/frame; one_shot; total 0.6 seconds. A natural blink, not an acknowledgement or a change in application state.

Change only the eyelids. Retain the neutral body, ears, eye-patch shapes, nose, mouth, paws, feet, camera, and light. The whole image must not be squashed to make the eyes close.

### Frames 00–03

Save the accepted raw row as `blink-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Quiet blink' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 6-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
Change only the eyelids. Retain the neutral body, ears, eye-patch shapes, nose, mouth, paws, feet, camera, and light. The whole image must not be squashed to make the eyes close.

Cell 1 (clip frame 00): Exact neutral reference; eyes fully open.
Cell 2 (clip frame 01): Upper eyelids half lowered over both eyes together; eye patches remain unchanged.
Cell 3 (clip frame 02): Eyes gently closed for this frame only; relaxed lids, no squeezed happy crescents and no cheek lift.
Cell 4 (clip frame 03): Eyes half reopened, reversing the eyelid action of frame 01.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–05

Save the accepted raw row as `blink-04-05.png`.

```text
Create exactly 2 consecutive animation frames for Dif's 'Quiet blink' clip in ONE horizontal row, left to right. Target image: 1024 x 512 pixels, with exactly 2 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 05 of a 6-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
Change only the eyelids. Retain the neutral body, ears, eye-patch shapes, nose, mouth, paws, feet, camera, and light. The whole image must not be squashed to make the eyes close.

Cell 1 (clip frame 04): Eyes fully open; exact neutral reference.
Cell 2 (clip frame 05): Exact neutral reference. The short open-eye tail belongs to this one-shot and is not a loop seam.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

## 05. compare_glance — Look between

8 frames; 150 ms/frame; one_shot; total 1.2 seconds. Looking between two sides. Not proof that any code has been inspected by an agent or that all differences are understood.

A restrained left-to-right glance. Eyes carry most of the action; head yaw is at most about two degrees. No magnifying glass, cards, arrows, or generated code.

### Frames 00–03

Save the accepted raw row as `compare_glance-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Look between' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
A restrained left-to-right glance. Eyes carry most of the action; head yaw is at most about two degrees. No magnifying glass, cards, arrows, or generated code.

Cell 1 (clip frame 00): Exact neutral reference, eyes forward.
Cell 2 (clip frame 01): Pupils glance a little toward the viewer's left; head and body stay centered.
Cell 3 (clip frame 02): Head follows the left glance with a very small yaw, no more than about two degrees.
Cell 4 (clip frame 03): Return through center; eyes look briefly forward.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–07

Save the accepted raw row as `compare_glance-04-07.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Look between' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 07 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
A restrained left-to-right glance. Eyes carry most of the action; head yaw is at most about two degrees. No magnifying glass, cards, arrows, or generated code.

Cell 1 (clip frame 04): Pupils glance a little toward the viewer's right.
Cell 2 (clip frame 05): Head follows the right glance by no more than about two degrees; shoulders remain level.
Cell 3 (clip frame 06): Eyes and head ease back toward front.
Cell 4 (clip frame 07): Exact neutral reference pose. Copy the locked source for the final handoff.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

## 06. consider — Thoughtful pause

8 frames; 150 ms/frame; one_shot; total 1.2 seconds. A brief thoughtful gesture accompanying separately rendered working status. Not a model identity, hidden reasoning display, or progress estimate.

Bring the viewer-left paw lightly near the chin, tilt the head a little, then return. This is a one-shot, not a pantomime that repeats for the entire task. No thought bubbles or floating dots.

### Frames 00–03

Save the accepted raw row as `consider-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Thoughtful pause' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
Bring the viewer-left paw lightly near the chin, tilt the head a little, then return. This is a one-shot, not a pantomime that repeats for the entire task. No thought bubbles or floating dots.

Cell 1 (clip frame 00): Exact neutral reference, relaxed and attentive.
Cell 2 (clip frame 01): Viewer-left paw begins lifting toward the chest.
Cell 3 (clip frame 02): Paw approaches the lower chin without covering the nose or mouth.
Cell 4 (clip frame 03): Paw rests lightly beneath the chin; head tilts about two degrees; eyes glance slightly upward.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–07

Save the accepted raw row as `consider-04-07.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Thoughtful pause' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 07 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
Bring the viewer-left paw lightly near the chin, tilt the head a little, then return. This is a one-shot, not a pantomime that repeats for the entire task. No thought bubbles or floating dots.

Cell 1 (clip frame 04): Small thoughtful hold with the same gentle expression, no furrowed angry brows.
Cell 2 (clip frame 05): Head straightens while the paw begins to lower.
Cell 3 (clip frame 06): Paw returns toward the side of the belly; gaze comes forward.
Cell 4 (clip frame 07): Exact neutral reference pose; copy the locked source at assembly.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

## 07. comment_ready — Here is the draft

8 frames; 125 ms/frame; one_shot; total 1 seconds. Invites the user to read a real draft. Does not say that the draft is correct, approved, or published.

Dif makes a small two-paw presentation gesture toward the real UI beside or below the illustration. The sprite itself contains no note, speech bubble, code, text, pen, or author badge.

### Frames 00–03

Save the accepted raw row as `comment_ready-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Here is the draft' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
Dif makes a small two-paw presentation gesture toward the real UI beside or below the illustration. The sprite itself contains no note, speech bubble, code, text, pen, or author badge.

Cell 1 (clip frame 00): Exact neutral reference, paws relaxed.
Cell 2 (clip frame 01): Both paws move slightly inward toward the lower belly.
Cell 3 (clip frame 02): Paws lift just a little, preparing a small open presentation gesture.
Cell 4 (clip frame 03): Both paws gently open forward, palm-up, below the face; head inclines slightly toward the nearby real UI.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–07

Save the accepted raw row as `comment_ready-04-07.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Here is the draft' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 07 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
Dif makes a small two-paw presentation gesture toward the real UI beside or below the illustration. The sprite itself contains no note, speech bubble, code, text, pen, or author badge.

Cell 1 (clip frame 04): Brief, calm presentation hold; no flourish, floating object, or talking mouth.
Cell 2 (clip frame 05): Paws begin closing the presentation gesture.
Cell 3 (clip frame 06): Paws lower toward their original resting positions.
Cell 4 (clip frame 07): Exact neutral reference pose; copy the locked source.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

## 08. attention — Worth a look

6 frames; 150 ms/frame; one_shot; total 0.9 seconds. Something merits the user's attention. A candidate finding is not a confirmed defect.

A small, polite raised-paw gesture and slightly more attentive eyes, followed by a return to neutral. No alarm, bouncing, red flash, exclamation symbol, bug, or accusing finger.

### Frames 00–03

Save the accepted raw row as `attention-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Worth a look' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 6-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
A small, polite raised-paw gesture and slightly more attentive eyes, followed by a return to neutral. No alarm, bouncing, red flash, exclamation symbol, bug, or accusing finger.

Cell 1 (clip frame 00): Exact neutral reference, eyes open.
Cell 2 (clip frame 01): Viewer-right paw begins rising close to the chest; eyes become slightly more attentive.
Cell 3 (clip frame 02): Paw held politely at chest height with pads angled gently toward the viewer; head tips a tiny amount forward.
Cell 4 (clip frame 03): Quiet attention hold, no shock or panic face.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–05

Save the accepted raw row as `attention-04-05.png`.

```text
Create exactly 2 consecutive animation frames for Dif's 'Worth a look' clip in ONE horizontal row, left to right. Target image: 1024 x 512 pixels, with exactly 2 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 05 of a 6-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
A small, polite raised-paw gesture and slightly more attentive eyes, followed by a return to neutral. No alarm, bouncing, red flash, exclamation symbol, bug, or accusing finger.

Cell 1 (clip frame 04): Paw lowers; head and eyes relax toward neutral.
Cell 2 (clip frame 05): Exact neutral reference pose; copy the locked source.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

## 09. acknowledge — A small nod

8 frames; 125 ms/frame; one_shot; total 1 seconds. That requested action completed. It does not mean the code is good, safe, reviewed, or approved.

One small affirmative nod with a warm, closed smile. Rotate the head a little; do not compress the entire body. No green check, thumbs-up, medal, confetti, or party pose.

### Frames 00–03

Save the accepted raw row as `acknowledge-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'A small nod' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
One small affirmative nod with a warm, closed smile. Rotate the head a little; do not compress the entire body. No green check, thumbs-up, medal, confetti, or party pose.

Cell 1 (clip frame 00): Exact neutral reference pose.
Cell 2 (clip frame 01): A barely perceptible preparation of the head for the nod; torso unchanged.
Cell 3 (clip frame 02): Head inclines downward a little; eyes remain naturally attentive.
Cell 4 (clip frame 03): Lowest point of one shallow nod, approximately three degrees; feet and belly unchanged.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–07

Save the accepted raw row as `acknowledge-04-07.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'A small nod' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 07 of a 8-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
One small affirmative nod with a warm, closed smile. Rotate the head a little; do not compress the entire body. No green check, thumbs-up, medal, confetti, or party pose.

Cell 1 (clip frame 04): Head begins rising from the nod.
Cell 2 (clip frame 05): Head almost level, smile still restrained.
Cell 3 (clip frame 06): Head settles, without a second nod or overshoot.
Cell 4 (clip frame 07): Exact neutral reference pose; copy the locked source.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

## 10. blocked — Patient help needed

6 frames; 150 ms/frame; one_shot; total 0.9 seconds. A calm invitation to read the real explanation and recovery controls; not shame, blame, or data loss.

A slight inquisitive head tilt and a small open-paw gesture. Keep the emotional tone patient and capable. No crying, sweat drop, anger, broken-object prop, shrugging despair, or question mark.

### Frames 00–03

Save the accepted raw row as `blocked-00-03.png`.

```text
Create exactly 4 consecutive animation frames for Dif's 'Patient help needed' clip in ONE horizontal row, left to right. Target image: 2048 x 512 pixels, with exactly 4 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 00 through 03 of a 6-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
A slight inquisitive head tilt and a small open-paw gesture. Keep the emotional tone patient and capable. No crying, sweat drop, anger, broken-object prop, shrugging despair, or question mark.

Cell 1 (clip frame 00): Exact neutral reference pose.
Cell 2 (clip frame 01): Head tilts gently toward the viewer's left; viewer-left paw begins to open near the belly.
Cell 3 (clip frame 02): Small open palm and about a three-degree head tilt, patient expression, eyes still friendly.
Cell 4 (clip frame 03): Quiet hold, inviting the user to inspect nearby real text and controls.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```

### Frames 04–05

Save the accepted raw row as `blocked-04-05.png`.

```text
Create exactly 2 consecutive animation frames for Dif's 'Patient help needed' clip in ONE horizontal row, left to right. Target image: 1024 x 512 pixels, with exactly 2 equal 512 x 512 cells, no inter-cell spacing and no outer sheet padding. This request covers frames 04 through 05 of a 6-frame clip. Do not restart the motion just because this is a new row.

Use the attached approved prop-free Dif neutral master as the sole character-model authority. This must be the same panda in every cell: pale lavender-white face and belly; purple ears, eye patches, short arms and feet; the same glossy dark eyes, small purple nose, gentle smile, head-to-body ratio, texture, silhouette, camera, and lighting. Do not reinterpret or average the character using a previous generated row. The original brand board is background art-direction reference only, not a grid to reproduce.

Render polished, softly dimensional plush-like 3D illustration as clean 2D RGBA sprites. Use the same front-facing, near-orthographic camera and soft frontal studio light. No camera motion, zoom, perspective change, palette shift, relighting, motion blur, loose fur, boiling texture, or cast/contact shadow. No extra characters, props, text, symbols, UI, code, logos, labels, cell outlines, floor, checkerboard pixels, glow, or sparkles.

Keep the pelvis, foot positions, ground line, and whole-body reference scale fixed in every cell. Change only the body parts specified in the choreography. Do not stretch or scale the entire panda to simulate a breath, blink, nod, or emotion. Do not center each frame on its changing visible silhouette. Keep raised paws within the reference head-width envelope and preserve the fixed body center. Never crop ears, paws, or feet.

Use genuinely transparent empty space, including the spaces between limbs. Preserve fine antialiased silhouette edges without a colored matte. Each 512 x 512 source cell has the same body reference center x=256 and a planted-foot line near y=446. Keep every visible pixel at least 32 pixels from every cell edge, and the body within the common containment envelope x=112..399, y=44..447. Do not distort the model to fill that envelope; final registration is verified offline.

This is a row of consecutive animation frames, not alternative character designs. No drawn separators and no blank leading or trailing cells: the asset compiler, not the image generator, adds the runtime's fully blank end cells. No unrequested duplicate poses. Output only the requested image row.

CHOREOGRAPHY
A slight inquisitive head tilt and a small open-paw gesture. Keep the emotional tone patient and capable. No crying, sweat drop, anger, broken-object prop, shrugging despair, or question mark.

Cell 1 (clip frame 04): Head straightens and the paw closes toward its resting pose.
Cell 2 (clip frame 05): Exact neutral reference pose; copy the locked source.

Only these frames belong in this image. No title, captions, frame numbers, or other poses.
```
