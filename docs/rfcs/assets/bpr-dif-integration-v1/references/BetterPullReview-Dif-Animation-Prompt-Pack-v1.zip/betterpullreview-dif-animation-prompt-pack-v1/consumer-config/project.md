# BetterPullReview — proposed sprite-sheet-animation-updater guidance

This file is a DRAFT. Intended consumer location: `.mask/skill-config/sprite-sheet-animation-updater/project.md`. Read and reconcile any existing consumer file before adding this guidance. Installing this text alone changes neither runtime admission nor RFC status.

## Source of truth

The consumer owns `src/adapters/qt/assets/dif/dif-sprite-manifest.json`, its source frames/provenance, `scripts/dif_assets.py`, `tests/scripts/dif_asset_tests.py`, RFC-BPR-0019, and RFC-BPR-0020. Inspect the live files; do not import another mascot's defaults. Dif is the purple-and-white panda. Nib/Mel are not BPR runtime characters.

## Creative direction

Preserve a frozen approved neutral master. The base representation is prop-free; any later diff-card variant remains independently source-owned and reviewed. Identity does not include a magnifying glass, petals, glow, or an automatic-review persona. Use stable camera, light, material, body scale, pelvis/foot registration, and transparent backgrounds. Do not scale an entire raster to simulate a blink, nod, or breath.

## Sheet contract

The existing runtime uses 256-square RGBA8 sRGB straight-alpha cells, one blank end cell on each side, and separate one-row strips for calm_idle/greet/rest. Source frames are square multiples of 256, max 2048 per dimension; master at least 512 square. Candidate authoring may use four-cell 512-square rows that are split offline into numbered source frames. Intermediates and optional clips remain outside the exact live asset root.

The current registered target is center x=128, alpha-bounds bottom=223 (exclusive), foot tolerance 1, edge clearance 16, and body containment [56,22,200,224]. Retain one neutral registration and inspect actual output. Never recenter a frame on a moving hand/prop.

## Validation

The shared validator's default blue-body detector does not apply. For unpadded 512-cell rows, use explicit flags, --alpha-threshold 0, --min-gutter 32, and --no-body-check. This is structural screening, not a body/identity/seam check. It reads active frames from column 0 and cannot directly accept BPR's leading blank cell. Use BPR's own generate/validate/verify/preview commands for the real candidate runtime products.

No runtime art generation, directory scanning, foreign animation engine, or hand editing of generated strips. Follow the existing canonical PNG and deterministic fixed-box reduction implementation; source and committed-output hashes stay bound to actual bytes. Record new production-source provenance and affected visual approvals rather than inheriting old verdicts by name.

## Product boundary

The admitted foundation is three decorative clips and landing-only placement. Reduced motion is awake/static rest; hidden/inactive means no timer work. Do not add random fidgets, interactive reactions, agent activity, defect findings, approval badges, or active-review placement without their explicit later design/implementation change. The supplied full repertoire is a proposal, not an expanded runtime manifest.
